README for ApiMkRngSeed.exe
===========================

`ApiMkRngSeed.exe` creates a new seed file with random entropy suitable for using with RNG_Initialize.
The user is prompted to press random keyboard keys and (Windows only) move the mouse over the dialog box.

The default seed file name is `seed.dat`. Any file of the same name will be overwritten without warning.

```
Usage: ApiMkRngSeed [OPTION]... [FILENAME] ["ALTPROMPT"]
Generate a new RNG seed file with random keyboard entries.
OPTIONS:
  -s {112|[128]|192|256} required security strength in bits
  -r use Intel(R) DRNG, if available, instead of keystrokes
  -h display this help and exit
  -v display version information and exit
FILENAME  Name of seedfile to be created (default='seed.dat')
ALTPROMPT Alternative prompt to use in dialog box
```

Requires CryptoSys API to be installed on your system. Available from
<https://www.cryptosys.net/api.html>

Updated December 2023 to use DRBG_HMAC SHA-512 with options to specify security strength
and January 2024 to add support for Intel(R) DRNG, if available.

David Ireland  
DI Management Services Pty Limited  
Australia  
<www.di-mgt.com.au>  
<www.cryptosys.net>  
This file last updated: 7 January 2024  
*****************************************
